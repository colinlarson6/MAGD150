
var x;

var offset = 10;
var x = 80;

var y = 50;

var w = 80;

var h = 60;

function setup() {
  // put setup code here
  createCanvas(500, 500)
  background(51)
  x = width/2;
}

function draw() {
  // put drawing code here

  background(204);

	if (mouseX > x) {

		x += 0.5;
		offset = -10;

	}

	if (mouseX < x) {

		x -= 0.5;
		offset = 10;

	}

	// Draw arrow left or right depending on "offset" value

	line(x, 0, x, height);

	line (mouseX, mouseY, mouseX + offset, mouseY - 10);

	line (mouseX, mouseY, mouseX + offset, mouseY + 10);
	
	line (mouseX, mouseY, mouseX + offset * 3, mouseY);

	background (204);

	if ((mouseX > x) && (mouseX < x+w) && (mouseY > y) && (mouseY < y+h)) {
		
		fill(0);
	}

	else {

		fill (255);

	}
	
	rect(x, y, w, h);
	colorMode(RGB, 700);
let c = color(600, 255, 79);



}

function mousePressed() {

	background (204);

	if ((mouseX > x) && (mouseX < x+w) && (mouseY > y) && (mouseY < y+h)) {
		
		fill(0);

	}

	else {

		fill (255);

	}
	
	rect(x, y, w, h);
	clr = color(500, 57, 45)

function draw() {
  if (keyIsPressed === true) {
    fill(0);
  } else {
    fill(255);
  }
  rect(25, 25, 50, 50);
}
















}









