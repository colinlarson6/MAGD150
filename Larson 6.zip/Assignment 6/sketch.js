function setup() {
  // put setup code here
  createCanvas(500, 500)
  background(151)
  	bug = new JitterBug(width/2, height/2, 20);

  	let x = 10;
print('The value of x is ' + x);
// prints "The value of x is 10"
}

function draw() {
  // put drawing code here
	bug.move();
	bug.display();
ellipse(0, 50, 33, 33); // Left circle

push(); // Start a new drawing state
strokeWeight(10);
fill(204, 153, 0);
ellipse(33, 50, 33, 33); // Left-middle circle

push(); // Start another new drawing state
stroke(0, 102, 153);
ellipse(66, 50, 33, 33); // Right-middle circle
pop(); // Restore previous state

pop(); // Restore original state

ellipse(100, 50, 33, 33); // Right circle
}

// JitterBug object

// Three properties or 'instance variables' are needed - passed in from line 11

function JitterBug(tempX, tempY, tempDiameter) {

	// local or variables are created with 'this.[variable-name]' syntax and set to incoming properties 

	this.x = tempX;

	this.y = tempY;

	this.diameter = tempDiameter;

	this.speed = 2.5;

	this.move = function () {

		this.x += random(-this.speed, this.speed);

		this.y += random (-this.speed, this.speed);

	};

	this.display = function () {

		ellipse(this.x, this.y, this.diameter, this.diameter);

	};

rect(0, 0, 55, 55); // Draw rect at original 0,0
translate(30, 20);
rect(0, 0, 55, 55); // Draw rect at new 0,0
translate(30, 14);
rect(0, 0, 55, 55); // Draw rect at new 0,0
translate(30,55);
rect(0, 0, 55, 55);
translate(30, 55);
rect(0, 0, 55, 55);
translate(-30, 55);
rect(0, 0, 55, 55);
translate(-30, 55);
rect(0, 0, 55, 55);
translate(-30, 14);
rect(0, 0, 55, 55);
translate(-30, 20);
rect(0, 0, 55, 55);



	for (var x = 35; x < width + 70; x += 70) {
		owl(x, 110);
	}
}

function owl(x, y) {

	push(); // create a new drawing state

	translate(x, y);

	stroke(0);

	strokeWeight(70);

	line (0, -35, 0, -65); // Body

	noStroke();

	fill(255);

	ellipse(-17.5, -65, 35, 35); // Left eye dome

	ellipse(17.5, -65, 35, 35); // Right eye dome

	arc(0, -65, 70, 70, 0, PI); // Chin

	fill(0);

	ellipse(-14, -65, 8, 8); // Left eye

	ellipse(14, -65, 8, 8); // Right eye

	quad(0, -58, 4, -51, 0, -44, -4, -51); // Beak

	pop(); 

}