function setup() {
  // put setup code here
  createCanvas(550, 600)
  strokeWeight(8);}
  

function draw() {
  // put drawing code here
  background(204);
  for (var i = 20; i < 400; i += 60) {
  	line(i, 40, i + 60, 80);
  }
  line (40, 0, 70, height);
  if (mouseIsPressed == true) {
  	stroke(30);
  }
  line(0, 70, width, 50);

  line (20, 20, 220, 100);
  if (keyIsPressed) {
  line(220, 20, 20, 100);
 }
  if (keyIsPressed) {
  	if (key == 'o') {
  		line(30, 60, 90, 60);
  	} 
    else if ( key == 'p') {
  		line (30, 20, 90, 100);
  	}
  }
  line(30, 20, 30, 100);
  line(190, 20, 90, 100);



}